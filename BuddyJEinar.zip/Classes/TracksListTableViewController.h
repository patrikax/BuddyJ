//
//  TracksListTableViewController.h
//  BuddyJ
//
//  Created by Leo Giertz on 100130.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TracksListTableViewController : UITableViewController {
    NSArray* tracks;
}

@end
