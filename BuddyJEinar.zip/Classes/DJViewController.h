//
//  DJViewController.h
//  BuddyJ
//
//  Created by Leo Giertz on 100130.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#include "AudioEngine.h"

@interface DJViewController : UIViewController {
	IBOutlet UIButton *playPauseBtn;
	AudioEngine *audioEngine;
	IBOutlet UISlider *pitchSlider;
}
- (IBAction)pitchSliderChanged:(id)sender;
- (IBAction)playPauseBtnClicked:(id)sender;

- (IBAction)showChooseTracks;

@end
